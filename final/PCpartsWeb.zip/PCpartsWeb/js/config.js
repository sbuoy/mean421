window._config = {
    cognito: {
        userPoolId: 'us-east-1_zBkWbcROK', // e.g. us-east-2_uXboG5pAb
        userPoolClientId: '6bq9kqlvlf0pqegm09ni8c81n2', // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region: 'us-east-1' // e.g. us-east-2
    },
    api: {
        invokeUrl: '' // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod',
    }
};